function index() {
    console.log("Hellow from Terraform-deployed Lambda function");
}